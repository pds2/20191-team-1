var indexSectionsWithContent =
{
  0: "beghilmnprtu",
  1: "ehprtu",
  2: "gilpt",
  3: "m",
  4: "bimn"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Arquivos",
  2: "Funções",
  3: "Variáveis",
  4: "Definições e Macros"
};


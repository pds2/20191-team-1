var searchData=
[
  ['tela_5fcomo_5fjogar',['tela_como_jogar',['../telas_8cpp.html#a9463a351c6a63e8a82df796197e45a8f',1,'telas.cpp']]],
  ['tela_5fdificuldade',['tela_dificuldade',['../telas_8cpp.html#a38709aa9275569423d2b4cb5b4aa6e5d',1,'telas.cpp']]],
  ['tela_5finicial',['tela_inicial',['../telas_8cpp.html#a2a194251baa5812baac5606d21cd97e5',1,'telas.cpp']]],
  ['tela_5fmonta_5fequipe',['tela_monta_equipe',['../telas_8cpp.html#a5d60215f887819614ba085bb984d3986',1,'telas.cpp']]],
  ['tela_5fmorte_5fheroi_5fsem_5fpedra',['tela_morte_heroi_sem_pedra',['../telas_8cpp.html#abda666ba3cb58109862c18f5fefd6505',1,'telas.cpp']]],
  ['tela_5fresultado_5fataque_5fjogador',['tela_resultado_ataque_jogador',['../telas_8cpp.html#a74e3d84db0dd2ed326b8f530f910c7a2',1,'telas.cpp']]],
  ['tela_5fresultado_5fataque_5fthanos',['tela_resultado_ataque_thanos',['../telas_8cpp.html#aa065b8cc0144104d7cc366bce848e9d0',1,'telas.cpp']]],
  ['tela_5fvitoria_5fjogador',['tela_vitoria_jogador',['../telas_8cpp.html#a12c3bf437c3c40963e090b0282c3edca',1,'telas.cpp']]],
  ['tela_5fvitoria_5fthanos',['tela_vitoria_thanos',['../telas_8cpp.html#a6dc010754ccab5b9ccd316ed00275abd',1,'telas.cpp']]],
  ['telas_2ecpp',['telas.cpp',['../telas_8cpp.html',1,'']]],
  ['thanos_2ecpp',['thanos.cpp',['../thanos_8cpp.html',1,'']]]
];

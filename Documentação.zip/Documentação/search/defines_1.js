var searchData=
[
  ['id_5fpedra',['ID_PEDRA',['../equipe_8cpp.html#afe4a6897e6e65c7174bc2c63efc965f2',1,'equipe.cpp']]]
];

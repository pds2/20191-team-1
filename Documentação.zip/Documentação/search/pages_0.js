var searchData=
[
  ['20191_2dteam_2d1_20_7c_20marvel_20rpg',['20191-team-1 | Marvel RPG',['../md__c_1__users__julinha__documents__git_hub_20191-team-1__r_e_a_d_m_e.html',1,'']]]
];

var searchData=
[
  ['partida_2ecpp',['partida.cpp',['../partida_8cpp.html',1,'']]],
  ['personagem_2ecpp',['personagem.cpp',['../personagem_8cpp.html',1,'']]]
];

var searchData=
[
  ['limpa_5ftela',['limpa_tela',['../util_8cpp.html#a14bbb58b733f41cf4c99b1a6b5d8f2e3',1,'util.cpp']]]
];
